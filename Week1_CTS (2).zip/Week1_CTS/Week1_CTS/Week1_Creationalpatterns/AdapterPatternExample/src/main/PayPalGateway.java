package main;

public class PayPalGateway {
    public void makePayment(double amount) {
        System.out.println("Processing payment with PayPal: $" + amount);
    }
}
