package main;

public class StripeGateway {
    public void charge(double amount) {
        System.out.println("Charging with Stripe: $" + amount);
    }
}
