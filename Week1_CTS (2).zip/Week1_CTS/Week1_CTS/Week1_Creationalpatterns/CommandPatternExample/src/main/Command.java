package main;
public interface Command {
    void execute();
}
