package main;

//DecoratorPatternExample.java
public class DecoratorPatternExample {
 public static void main(String[] args) {
     Notifier emailNotifier = new EmailNotifier();
     
     Notifier emailAndSMSNotifier = new SMSNotifierDecorator(emailNotifier);
     
     Notifier emailSMSAndSlackNotifier = new SlackNotifierDecorator(emailAndSMSNotifier);
     
     System.out.println("Sending with EmailNotifier:");
     emailNotifier.send("Hello via Email!");
     
     System.out.println("\nSending with EmailNotifier and SMSNotifier:");
     emailAndSMSNotifier.send("Hello via Email and SMS!");
     
     System.out.println("\nSending with EmailNotifier, SMSNotifier, and SlackNotifier:");
     emailSMSAndSlackNotifier.send("Hello via Email, SMS, and Slack!");
 }
}
