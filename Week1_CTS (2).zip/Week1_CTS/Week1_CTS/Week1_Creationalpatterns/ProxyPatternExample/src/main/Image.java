package main;

//Image.java
public interface Image {
 void display();
}
