package main;

public class Main {
    public static void main(String[] args) {
        PaymentContext context = new PaymentContext();

        // Pay using Credit Card
        context.setPaymentStrategy(new CreditCardPayment("1234567890123456", "John Doe", "123", "12/25"));
        context.pay(100.00);

        // Pay using PayPal
        context.setPaymentStrategy(new PayPalPayment("john.doe@example.com", "password123"));
        context.pay(200.00);
    }
}
